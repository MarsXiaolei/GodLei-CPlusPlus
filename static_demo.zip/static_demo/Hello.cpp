#include "Hello.h"

int Hello::num = 5;

Hello::Hello(int n):value(n)
{
}
