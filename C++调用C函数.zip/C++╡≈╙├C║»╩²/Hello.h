#ifndef __HELLO_H__
#define __HELLO_H__

extern void print_c();

extern void add_c(int value1,int value2);

#endif
