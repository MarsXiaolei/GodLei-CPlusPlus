#pragma once

extern "C" void subtract_cpp(int value1, int value2);

class Test
{
public:
	Test();
	~Test();
	void print_cpp();
private:

};

