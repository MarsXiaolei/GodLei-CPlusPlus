#include <stdio.h>
#include "Hello.h"

void print_c()
{
	printf("print_c->hello world!\n");
}

void add_c(int value1, int value2)
{
	int sum = 0;
	sum = value1 + value2;
	printf("add_c->sum=%d\n",sum);
}
