#include "Test.h"
#include <iostream>

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

#include "Hello.h"

#ifdef __cplusplus
}
#endif // __cplusplus


Test::Test()
{
}

Test::~Test()
{
}

void Test::print_cpp()
{
	std::cout << "print_cpp->hello world!" << std::endl;
	add_c(1,2);
}

